/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyectoestructuras;

import com.mycompany.proyectoestructuras.VentanaPrincipal;
import com.mycompany.proyectoestructuras.Auto;
import com.mycompany.proyectoestructuras.NodoAuto;
import javax.swing.JOptionPane;

/**
 *
 * @author 50662
 */
public class AutoServicio extends javax.swing.JFrame {
public NodoAuto cabeza;
public  NodoAuto ultimo;
int contPoder=0;
int Electrico;
int Gasolina;
int Gas;

    
    
    public AutoServicio() {
        initComponents();
        this.cabeza=null;
    }

    //AGREGAMOS LOS METODOS
    
    
    public void insertar(Auto auto){
        //Agregamos autos a la cola
           if (cabeza==null) {
            cabeza=new NodoAuto(auto);
              if(cabeza.dato.tipoCombustible=="Electrico"){
                Electrico++;
            }
           if(cabeza.dato.tipoCombustible=="Gas"){
                Gas++;
            }
           if(cabeza.dato.tipoCombustible=="Gasolina"){
               Gasolina++;
            }
           
            ultimo=cabeza;
            
        }else{
            ultimo.siguiente=new NodoAuto(auto);
            if(ultimo.siguiente.dato.tipoCombustible=="Electrico"){
                Electrico++;
            }
           if(ultimo.siguiente.dato.tipoCombustible=="Gas"){
                Gas++;
            }
           if(ultimo.siguiente.dato.tipoCombustible=="Gasolina"){
               Gasolina++;
            }
           
           ultimo=ultimo.siguiente;
            
        }
       
   
        
    }
    
    public void TipoCombustible(){
        //nos permite mostrar todos los autos con su debido tipo de combustible
        
            JOptionPane.showMessageDialog(null, "El numero de autos que espera ser atendidos de tipo de combustible 'Gasolina' son: "+Gasolina+" Autos"
            +"\n"+ "El numero de autos que espera ser atendidos de tipo de combustible 'Electrico' son: "+Electrico+" Autos"
             +"\n"+"El numero de autos que espera ser atendidos de tipo de combustible 'Gas' son: "+Gas+" Autos");
      

    
    }
    
    public void Eliminar(){
        NodoAuto aux=cabeza;
        //se crea un nodo para recorrer la cola
           
        if (cabeza!=null) { 
            if (cabeza.dato.tipoCombustible=="Electrico") {
                Electrico=Electrico-1;
            }if (cabeza.dato.tipoCombustible=="Gas") {
                Gas=Gas-1;
            }if (cabeza.dato.tipoCombustible=="Gasolina") {
                Gasolina=Gasolina-1;
            }
             //se adquiere el tipo de combustible de los autos para eliminarlos del contador general
             
             
             
            cabeza=cabeza.getSiguiente();
            //la cabeza se convierte en la cabeza siguiente
            JOptionPane.showMessageDialog(null,  "Has atendido al auto: "+"\n"+"Tipo: "+aux.dato.tipoAuto+"\n"+"Año: "+aux.dato.año+"\n"+"Tipo de combustible: "+aux.dato.tipoCombustible);
            
            contPoder++;
            //sube el contador del poder
            
            aux.setSiguiente(null);//Se borran los datos del nodo a eliminar
         if(contPoder==4){
                contPoder=1;
            }
            if (contPoder==3 && cabeza!=null) {
                usarPoder.setEnabled(true);
               
            } else{

                usarPoder.setEnabled(false); 
            }
            //se hacen todos los calculos para el funcionamiento del poder
            
            
        }else{
          JOptionPane.showMessageDialog(null,  "No hay autos esperando...");  
          //se mustra el mensaje que ya no hay autos esperando
          
        }
    }
    
    public void Mostrar(){
       
    //MOSTRAR LA COLA DE AUTOS A ATENDER
   NodoAuto aux = cabeza;
   //se crea un nodo que recorra la cola
   
   int contador=0;
   //se crea un contador para llevar un orden
   String mensaje1="";
   //se crea una variable para mostrar mensajes
 
        while(aux!=null){
            contador++;
            mensaje1=mensaje1+("\n"+contador+" "+"||\t"+"Tipo= "+ aux.dato.tipoAuto+"\n"+"Año= "+aux.dato.año+"\n"+"Tipo de combustible= "+aux.dato.tipoCombustible+ "\t"+"\n");
            
            aux = aux.getSiguiente();
            //recorre la cola 
        }
       
        JOptionPane.showMessageDialog(null, mensaje1);
        //se mustra el mensaje de los autos pendientes
}    
   
public void Poder(){
     //EL PODER PODRA USARSE CADA VEZ QUE SE ATIENDAN 3 AUTOS SEGUIDOS Y ELIMINARA 3 AUTOS SEGUIDOS
    if (cabeza==null) {
        //SI YA LA COLA ESTA VACIA MANDARA EL SIGUIENTE MENSAJE Y EN CASO DE QUE EL BOTON ESTE ACTIVADO
        JOptionPane.showMessageDialog(null, "Has acabado con todos los autos, felicidades!!!");
    }else{
         //SE ELIMINAN LOS TRES AUTOS DE LA COLA CON EL METODO DE ELIMINAR NODO
    Eliminar();
    Eliminar();
    Eliminar();
   
}    
}   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        regresar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        ayuda = new javax.swing.JButton();
        VerCola = new javax.swing.JButton();
        atender = new javax.swing.JButton();
        usarPoder = new javax.swing.JButton();
        VerTipoCombustible = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AutoServicio");
        setBackground(new java.awt.Color(0, 0, 255));

        jPanel1.setBackground(new java.awt.Color(131, 0, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        regresar.setBackground(new java.awt.Color(255, 0, 0));
        regresar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(255, 255, 255));
        regresar.setText("Regresar");
        regresar.setFocusPainted(false);
        regresar.setFocusable(false);
        regresar.setRequestFocusEnabled(false);
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });
        jPanel1.add(regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 30));

        jButton2.setBackground(new java.awt.Color(255, 0, 0));
        jButton2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Comenzar");
        jButton2.setFocusPainted(false);
        jButton2.setFocusable(false);
        jButton2.setRequestFocusEnabled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, -1, 30));

        ayuda.setBackground(new java.awt.Color(255, 0, 0));
        ayuda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        ayuda.setForeground(new java.awt.Color(255, 255, 255));
        ayuda.setText("Ayuda");
        ayuda.setFocusPainted(false);
        ayuda.setFocusable(false);
        ayuda.setRequestFocusEnabled(false);
        ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ayudaActionPerformed(evt);
            }
        });
        jPanel1.add(ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 10, -1, 30));

        VerCola.setBackground(new java.awt.Color(246, 170, 0));
        VerCola.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        VerCola.setForeground(new java.awt.Color(255, 255, 255));
        VerCola.setText("Ver cola de Autos");
        VerCola.setEnabled(false);
        VerCola.setFocusPainted(false);
        VerCola.setFocusable(false);
        VerCola.setRequestFocusEnabled(false);
        VerCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerColaActionPerformed(evt);
            }
        });
        jPanel1.add(VerCola, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 60, -1, -1));

        atender.setBackground(new java.awt.Color(246, 170, 0));
        atender.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        atender.setForeground(new java.awt.Color(255, 255, 255));
        atender.setText("Atender Auto");
        atender.setEnabled(false);
        atender.setFocusPainted(false);
        atender.setFocusable(false);
        atender.setRequestFocusEnabled(false);
        atender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atenderActionPerformed(evt);
            }
        });
        jPanel1.add(atender, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 240, -1, -1));

        usarPoder.setBackground(new java.awt.Color(246, 170, 0));
        usarPoder.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        usarPoder.setForeground(new java.awt.Color(255, 255, 255));
        usarPoder.setText("Usar Poder");
        usarPoder.setEnabled(false);
        usarPoder.setFocusPainted(false);
        usarPoder.setFocusable(false);
        usarPoder.setRequestFocusEnabled(false);
        usarPoder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usarPoderActionPerformed(evt);
            }
        });
        jPanel1.add(usarPoder, new org.netbeans.lib.awtextra.AbsoluteConstraints(88, 240, -1, -1));

        VerTipoCombustible.setBackground(new java.awt.Color(246, 170, 0));
        VerTipoCombustible.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        VerTipoCombustible.setForeground(new java.awt.Color(255, 255, 255));
        VerTipoCombustible.setText("Ver numero de tipo de combustible");
        VerTipoCombustible.setEnabled(false);
        VerTipoCombustible.setFocusPainted(false);
        VerTipoCombustible.setFocusable(false);
        VerTipoCombustible.setRequestFocusEnabled(false);
        VerTipoCombustible.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerTipoCombustibleActionPerformed(evt);
            }
        });
        jPanel1.add(VerTipoCombustible, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\50662\\Downloads\\ImagenesProyectoJava\\autoservicio1.jpg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ayudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ayudaActionPerformed
       AyudaAutoServicio ayudaAutoServicio=new AyudaAutoServicio();
       ayudaAutoServicio.setVisible(true);
    }//GEN-LAST:event_ayudaActionPerformed

    private void atenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atenderActionPerformed
        Eliminar();
    }//GEN-LAST:event_atenderActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        VentanaPrincipal ventanaPrincipal1=new VentanaPrincipal();
        ventanaPrincipal1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_regresarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        atender.setEnabled(true);
        VerCola.setEnabled(true);
        VerTipoCombustible.setEnabled(true);
        insertar(new Auto("Carro",2019,"Gasolina"));
        insertar(new Auto("Moto",2015,"Gasolina"));
        insertar(new Auto("Carro",2021,"Electrico"));
        insertar(new Auto("Moto",2022,"Electrico"));
        insertar(new Auto("Carro",2002,"Gasolina"));
         insertar(new Auto("Carro",2019,"Electrico"));
          insertar(new Auto("Moto",2012,"Gasolina"));
           insertar(new Auto("Carro",2013,"Gasolina"));
            insertar(new Auto("Carro",2019,"Gas"));
        jButton2.setEnabled(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void VerColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerColaActionPerformed
        Mostrar();
    }//GEN-LAST:event_VerColaActionPerformed

    private void VerTipoCombustibleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerTipoCombustibleActionPerformed
        TipoCombustible();
    }//GEN-LAST:event_VerTipoCombustibleActionPerformed

    private void usarPoderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usarPoderActionPerformed
         if (contPoder==3) {
            
            Poder();
           contPoder=0;
           usarPoder.setEnabled(false);
           
        }
    }//GEN-LAST:event_usarPoderActionPerformed


    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AutoServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AutoServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AutoServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AutoServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AutoServicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton VerCola;
    private javax.swing.JButton VerTipoCombustible;
    private javax.swing.JButton atender;
    private javax.swing.JButton ayuda;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton regresar;
    private javax.swing.JButton usarPoder;
    // End of variables declaration//GEN-END:variables
}
