
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class NodoAuto {
    public Auto dato;
    public NodoAuto siguiente;

    public NodoAuto(Auto dato) {
        this.dato = dato;
    }

    public Auto getDato() {
        return dato;
    }

    public void setDato(Auto dato) {
        this.dato = dato;
    }

    public NodoAuto getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoAuto siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
}
