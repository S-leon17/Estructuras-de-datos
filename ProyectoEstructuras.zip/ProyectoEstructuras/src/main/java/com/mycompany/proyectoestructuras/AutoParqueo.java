/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class AutoParqueo {
    public int id;
    public String tipoAuto;
    public Boolean disponible;

    public AutoParqueo(int id, String tipoAuto, Boolean disponible) {
        this.id = id;
        this.tipoAuto = tipoAuto;
        this.disponible = disponible;
    }

    public AutoParqueo() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipoAuto() {
        return tipoAuto;
    }

    public void setTipoAuto(String tipoAuto) {
        this.tipoAuto = tipoAuto;
    }

    public Boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }
    
    
   
}
