/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyectoestructuras;

import javax.swing.JOptionPane;


public class ValetParking extends javax.swing.JFrame {
public NodoParqueo cabeza;  // hace referencia a la cabeza de la lista
public NodoParqueo ultimo;    // hace referencia al ultimo de la lista
String mensaje1="";  // Se utilizara para mostrar mensajes a lo largo del programa



    public ValetParking() {
        initComponents();
        this.cabeza=null;
    }


    public void insertar(AutoParqueo espacio){
        if(cabeza==null){
            
            cabeza= new NodoParqueo(espacio);
            //si la cabeza es nula se agrega el nodo conviertiendose en la cabeza
            
            ultimo=cabeza;
            //convertimos el ultimo llega a ser la cabeza ya que solo hay un nodo en la lista
            
            ultimo.setSiguiente(cabeza);
            //se conecta el ultimo siguiente con la cabeza de la lista
            
            cabeza.setAtras(ultimo);
            //se conecta la cabeza atras con el ultimo de la lista
            
        }else if(espacio.getId()<cabeza.getEspacio().getId()){
            //si es nodo a insertar cuenta con un id menor al de la cabeza
               
                NodoParqueo aux=new NodoParqueo(espacio);
                 //se crea un nodo aux 
                 
                aux.setSiguiente(cabeza);
                //el valor siguiente del nodo aux se apunta a la cabeza
                cabeza=aux;
                //la cabeza se convierte en el nodo a ingresar
                
                ultimo.setSiguiente(cabeza);
                //el ultimo siguiente de la lista se apunta a la cabeza
                
                cabeza.setAtras(ultimo);
                //la cabeza atras apunta al ultimo valor de la lista
                
        }else if(ultimo.getEspacio().getId()<=espacio.getId()){
            //si el valor de ultimo tiene un valor menor o igual del nodo que se va a insertar 
            
            ultimo.setSiguiente(new NodoParqueo(espacio));
            //el ultimo siguiente va a apuntar al nuevo nodo agregado
          
            ultimo=ultimo.getSiguiente();
            //el ultimo ahora sera el nuevo nodo a agregar
           
            ultimo.setSiguiente(cabeza);
            //el ultimo siguiente apuntara a la cabeza
            cabeza.setAtras(ultimo);
            //la cabeza atras ahora apuntara al ultimo 
            
        } else{
            //para ingresar valores en medio
           
            NodoParqueo aux=cabeza;
            //se crea un nodo aux con valor de cabeza
            
            while (aux.getSiguiente().getEspacio().getId()<espacio.getId()) {       
                //hasta que el id de aux sea menor al del la variable espacio
                
                aux=aux.getSiguiente();
                //va recorriendo la variable aux por toda la lista
            }
            
            NodoParqueo temp= new NodoParqueo(espacio);
            //se crea un nodo temp
            
            temp.setSiguiente(aux.getSiguiente());
            //se enlaza temp al siguiente de aux
            
            temp.setAtras(aux);
            //temp se enlaza al de atras
           
            aux.setSiguiente(temp);
            //enalaza el siguiente de aux a temp
            
            temp.getSiguiente().setAtras(temp);
            //enlaza el siguiente a temp
        }
            
    }
    

  public void mostrar(){
      //nos muestra la lista para atras o hacia adelente
      
      NodoParqueo aux = cabeza;
      //se crea un nodo que recorra la lista
      
          if (cabeza!=null) {
              // si la cabeza no es nula
              
              while(true==true){
                  
    int seleccion=JOptionPane.showOptionDialog(null, "Id: "+aux.espacio.id+"   Auto: "+aux.espacio.tipoAuto+"  Disponible: "+aux.espacio.disponible,
  "Selector de opciones",JOptionPane.YES_NO_CANCEL_OPTION,
   JOptionPane.QUESTION_MESSAGE,null,
  new Object[] { "Atras", "Salir", "Siguiente"  },"opcion 1");
    //se crea una ventana con 3 opciones que captura la opcion seleccionada
    
    
  if(seleccion==1){
      break;
      //sale de la ventana
      
  }else if(seleccion==2){
      aux=aux.siguiente;
      //muestra el siguiente nodo de la lista
      
  }else if (seleccion==0){
      aux=aux.atras;
      //mustra el nodo anterior de la lista
      
  }

 
 }

}else{
              JOptionPane.showMessageDialog(null,"No tienes autos en el parqueo...");
              // si no hay autos en el parqueo
          }  
  }  
    
   public void modificar(){
       //permite el modificar los campos del parqueo para parquear un carro
       
       NodoParqueo aux=cabeza;
       //un nodo que logra recorrer la lista
       while(true==true){
           if (aux.espacio.disponible==true) {
              aux.espacio.tipoAuto=JOptionPane.showInputDialog(null, "Digite el tipo de auto (Carro o Moto): ");
              //si encuentra un espacio disponible
              
              aux.espacio.disponible=false;
              break;
              //cambia el estado del campo a ocupoado y sale del ciclo
           }
           
           
           if (aux==ultimo) {
               
               JOptionPane.showMessageDialog(null, "No hay espacios disponibles en el parqueo...");
               break;
               //si no encuentra espacios disponibles lo avisa y sale del ciclo
           }
           
       aux=aux.siguiente;
       //avanza por la lista
       }
       
   } 
    
    
    public void RetirarAuto(){
        //modifica la lista para cambiar el estado del espacio a no disponoble
        
        int indicador=0;
        //nos ayudara a tener un tipo de indicador para tomar las decisiones
        
        int index=Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero de espacio del estacionamiento del cual desea retirar un vehiculo: "));
         NodoParqueo aux=cabeza;
         //pide el numero de espacio del cual desea retirar y crea un nodo que recorra la lista
         if(index>10){
               JOptionPane.showMessageDialog(null, "Lo sentimos el numero de espacio digitado no se encuentra en el estacionamiento...");
               indicador=1;
               //si el espacio a retirar digitado es mayor a 10 se indica que no existe y el indicador cambia a 1
         }
         
       while(indicador==0){
           //si el indicador es 0 es por que el es un valor menor a 10
           
           if (aux.espacio.id==index) {
               
               if (aux.espacio.disponible==true) {
                
                   JOptionPane.showMessageDialog(null, "Lo sentimos el espacio ya esta vacio");
                   break;
                   //en caso de que el espacio ya este disponible se indica y sale del ciclo
                   
               }
              //si el espacio esta vacio se modifican sus valores
               aux.espacio.tipoAuto="Ninguno";
              aux.espacio.disponible=true;
              JOptionPane.showMessageDialog(null, "Se ha retirado exitosamente el espacio numero: "+aux.espacio.id+" del parqueo.");
              //se indica si se realizo exitisamente la extraccion
              break;
              
           }
           
       aux=aux.siguiente;
       //avanza en la lista
       }
       
    }
    
    
    
   
    public void VerDisponibles(){
    //nos muestra los espacios disponibles
        
   NodoParqueo aux = cabeza;
   //un nodo que recorre la lista
   
   int contador=0;
   //un contador para dar estetica
 
        while(true==true){
            if (aux.espacio.disponible==true) {
                 contador++;
            mensaje1=mensaje1+("\n"+contador+" Disponible "+"|\t"+" "+ aux.espacio.id+" "+ "\t|");
            //guarda los espacios disponibles en la varieble mensaje1\
            
            }
             if (aux==ultimo) {
                break;
                //si recorrio toda la lista sale
            }
            
            aux = aux.siguiente;
          //avamza por la lista
          
        }
        if (mensaje1=="") {
            mensaje1="No se encuentran espacios libres en el parqueo, lo sentimos...";
            //si no hay espacios disponobles lo muestra
        }
       
        
}    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        agregarCarro = new javax.swing.JButton();
        Regresar = new javax.swing.JButton();
        Empezar = new javax.swing.JButton();
        Ayuda = new javax.swing.JButton();
        VerEspacios = new javax.swing.JButton();
        VerParqueo = new javax.swing.JButton();
        Retirar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Valet Parking");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(110, 110, 110));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        agregarCarro.setBackground(new java.awt.Color(246, 170, 0));
        agregarCarro.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        agregarCarro.setForeground(new java.awt.Color(255, 255, 255));
        agregarCarro.setText("Parquear Auto");
        agregarCarro.setEnabled(false);
        agregarCarro.setFocusPainted(false);
        agregarCarro.setFocusable(false);
        agregarCarro.setRequestFocusEnabled(false);
        agregarCarro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarCarroActionPerformed(evt);
            }
        });
        jPanel1.add(agregarCarro, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 232, 150, 30));

        Regresar.setBackground(new java.awt.Color(255, 0, 0));
        Regresar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setText("Regresar");
        Regresar.setFocusPainted(false);
        Regresar.setFocusable(false);
        Regresar.setRequestFocusEnabled(false);
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        jPanel1.add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 30));

        Empezar.setBackground(new java.awt.Color(255, 0, 0));
        Empezar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Empezar.setForeground(new java.awt.Color(255, 255, 255));
        Empezar.setText("Empezar");
        Empezar.setFocusPainted(false);
        Empezar.setFocusable(false);
        Empezar.setRequestFocusEnabled(false);
        Empezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpezarActionPerformed(evt);
            }
        });
        jPanel1.add(Empezar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, -1, 30));

        Ayuda.setBackground(new java.awt.Color(255, 0, 0));
        Ayuda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Ayuda.setForeground(new java.awt.Color(255, 255, 255));
        Ayuda.setText("Ayuda");
        Ayuda.setFocusPainted(false);
        Ayuda.setFocusable(false);
        Ayuda.setRequestFocusEnabled(false);
        Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AyudaActionPerformed(evt);
            }
        });
        jPanel1.add(Ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 6, -1, 30));

        VerEspacios.setBackground(new java.awt.Color(246, 170, 0));
        VerEspacios.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        VerEspacios.setForeground(new java.awt.Color(255, 255, 255));
        VerEspacios.setText("Ver espacios disponibles");
        VerEspacios.setEnabled(false);
        VerEspacios.setFocusPainted(false);
        VerEspacios.setFocusable(false);
        VerEspacios.setRequestFocusEnabled(false);
        VerEspacios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerEspaciosActionPerformed(evt);
            }
        });
        jPanel1.add(VerEspacios, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 70, -1, 28));

        VerParqueo.setBackground(new java.awt.Color(246, 170, 0));
        VerParqueo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        VerParqueo.setForeground(new java.awt.Color(255, 255, 255));
        VerParqueo.setText("Ver parqueo");
        VerParqueo.setEnabled(false);
        VerParqueo.setFocusPainted(false);
        VerParqueo.setFocusable(false);
        VerParqueo.setRequestFocusEnabled(false);
        VerParqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerParqueoActionPerformed(evt);
            }
        });
        jPanel1.add(VerParqueo, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, 120, 32));

        Retirar.setBackground(new java.awt.Color(246, 170, 0));
        Retirar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Retirar.setForeground(new java.awt.Color(255, 255, 255));
        Retirar.setText("Retirar Auto");
        Retirar.setEnabled(false);
        Retirar.setFocusPainted(false);
        Retirar.setFocusable(false);
        Retirar.setRequestFocusEnabled(false);
        Retirar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RetirarActionPerformed(evt);
            }
        });
        jPanel1.add(Retirar, new org.netbeans.lib.awtextra.AbsoluteConstraints(88, 232, 130, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\50662\\Downloads\\ImagenesProyectoJava\\Parqueo2.jpg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, -4, 550, 310));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        VentanaPrincipal ventranaPrincipal1= new VentanaPrincipal();
        ventranaPrincipal1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegresarActionPerformed

    private void EmpezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpezarActionPerformed
        VerParqueo.setEnabled(true);
        Retirar.setEnabled(true);
        VerEspacios.setEnabled(true);
        agregarCarro.setEnabled(true); 
        insertar(new AutoParqueo(1, "Ninguno",true));   
        insertar(new AutoParqueo(10, "Moto",false));
        insertar(new AutoParqueo(8, "Ninguno",true));
     insertar(new AutoParqueo(9, "Carro",false)); 
      insertar(new AutoParqueo(6, "Ninguno",true));   
     insertar(new AutoParqueo(7, "Carro",false)); 
          insertar(new AutoParqueo(4, "Ninguno",true));
     insertar(new AutoParqueo(5, "Moto",false));      
        insertar(new AutoParqueo(2, "Ninguno",true));
     insertar(new AutoParqueo(3, "Carro",false));            
        Empezar.setEnabled(false);
    }//GEN-LAST:event_EmpezarActionPerformed

    private void VerEspaciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerEspaciosActionPerformed
        VerDisponibles();
        JOptionPane.showMessageDialog(null, mensaje1);
        mensaje1="";
    }//GEN-LAST:event_VerEspaciosActionPerformed

    private void VerParqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerParqueoActionPerformed
       mostrar();
    }//GEN-LAST:event_VerParqueoActionPerformed

    private void agregarCarroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarCarroActionPerformed
        modificar();
    }//GEN-LAST:event_agregarCarroActionPerformed

    private void RetirarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RetirarActionPerformed
        RetirarAuto();
    }//GEN-LAST:event_RetirarActionPerformed

    private void AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AyudaActionPerformed
        AyudaValetParking ayudaValetParking=new AyudaValetParking();
        ayudaValetParking.setVisible(true);
    }//GEN-LAST:event_AyudaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ValetParking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ValetParking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ValetParking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ValetParking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ValetParking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ayuda;
    private javax.swing.JButton Empezar;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton Retirar;
    private javax.swing.JButton VerEspacios;
    private javax.swing.JButton VerParqueo;
    private javax.swing.JButton agregarCarro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
