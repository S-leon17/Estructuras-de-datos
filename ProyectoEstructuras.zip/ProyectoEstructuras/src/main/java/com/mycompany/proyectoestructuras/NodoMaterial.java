/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class NodoMaterial {
    public Materiales material;
    public NodoMaterial siguiente;

    public NodoMaterial(Materiales material) {
        this.material = material;
    }

    public Materiales getMaterial() {
        return material;
    }

    public void setMaterial(Materiales material) {
        this.material = material;
    }

    public NodoMaterial getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoMaterial siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
}
