/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Llamada de la ventana principal
        VentanaPrincipal ventanaPrincipal1=new VentanaPrincipal();
         ventanaPrincipal1.setVisible(true);
         
         //Agregamos nuestros trastes a la pila 
         LavaplatosVent LavaplatosVent1=new LavaplatosVent();
         LavaplatosVent1.agregar("Plato");
         LavaplatosVent1.agregar("Plato");
         LavaplatosVent1.agregar("Vaso");
         LavaplatosVent1.agregar("plato");
         LavaplatosVent1.agregar("Vaso");
       LavaplatosVent1.agregar("plato");
         LavaplatosVent1.agregar("Vaso");  
        LavaplatosVent1.agregar("plato");
          LavaplatosVent1.agregar("Vaso");
         LavaplatosVent1.agregar("plato");
         LavaplatosVent1.agregar("plato");
//         LavaplatosVent1.Mostrar();
         
    }
    
}
