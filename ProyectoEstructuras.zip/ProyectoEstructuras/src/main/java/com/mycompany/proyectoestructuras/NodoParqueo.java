/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class NodoParqueo {
    
    public AutoParqueo espacio;
    public NodoParqueo siguiente;
    public NodoParqueo atras;

    public NodoParqueo getAtras(){
        return atras;
    }
    
    public void setAtras(NodoParqueo atras){
        this.atras=atras;
    }
    
    public NodoParqueo(AutoParqueo espacio){
        this.espacio=espacio;
    }
    
    public AutoParqueo getEspacio(){
        return espacio;
    }
    
    public void setEspacio(AutoParqueo espacio){
        this.espacio =espacio;
    }
    
    public NodoParqueo getSiguiente(){
        return siguiente;
    }
    public void setSiguiente(NodoParqueo siguiente){
        this.siguiente=siguiente;
    }
    
    
}
