package com.mycompany.proyectoestructuras;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */


import com.mycompany.proyectoestructuras.VentanaPrincipal;
import com.mycompany.proyectoestructuras.NodoPila;
import com.mycompany.proyectoestructuras.Traste;
import javax.swing.JOptionPane;


public class LavaplatosVent extends javax.swing.JFrame{
public NodoPila cima;
int contPoder=0;



   
    public LavaplatosVent() {
        initComponents();
        this.cima=null;
    }
    
  //AQUI EMPIEZAN LOS METODOS

    public void agregar(String tipo){    
        //AGREGA TRASTES A LA PILA DE TRASTES
        Traste nuevoTraste=new Traste();
        nuevoTraste.setTipo(tipo);
        
        
        NodoPila nuevoNodo=new NodoPila();
        nuevoNodo.setTraste(nuevoTraste);
        
        if(cima==null){
            cima=nuevoNodo;
            
        }else{
            nuevoNodo.setSiguiente(cima);
            cima=nuevoNodo;
        }
        
    }
           
 
    
    
    
    public void eliminarNodo(){
        //ELIMINA LOS NODOS DE NUESTRA PILA
        if (cima!=null) {
           //INFORMA QUE TRASTE FUE EL ELIMINADO
            JOptionPane.showMessageDialog(null, "El traste "+cima.traste.tipo+" ha sido lavado.");
            //LA CIMA PASA A SER EL PLATO QUE ESTABA ABAJO DE LA CIMA Y ESTO NOS PERMITE ELIMINAR UN TRASTE DE LA PILA
            cima=cima.getSiguiente();
            contPoder=contPoder+1;
            if(contPoder==4){
                contPoder=1;
            }
            if (contPoder==3 && cima!=null) {
                poder.setEnabled(true);
               
            }
            else{
                
           
                poder.setEnabled(false); 
                
            }
     
        }else{
            JOptionPane.showMessageDialog(null, "Has acabado con todos los platos, felicidades bro!!!");
        }
    }

    
    
    
    
public void Mostrar(){
    //MOSTRAR LA PILA DE TRASTES SUCIOS
   NodoPila aux = cima;
   int contador=0;
   String mensaje1="";
 
        while(aux != null){
            contador++;
            mensaje1=mensaje1+("\n"+contador+" "+"|\t"+" "+ aux.traste.tipo+" "+ "\t|");
            
            aux = aux.getSiguiente();
        }
       
        JOptionPane.showMessageDialog(null, mensaje1);
}    

public void Poder(){
    //EL PODER PODRA USARSE CADA VEZ QUE SE LAVEN 3 PLATOS SEGUIDOS Y ELIMINARA 3 PLATOS SEGUIDOS
    if (cima==null) {
        //SI YA LA PILA ESTA VACIA MANDARA EL SIGUIENTE MENSAJE Y EN CASO DE QUE EL BOTON ESTE ACTIVADO
        JOptionPane.showMessageDialog(null, "Has acabado con todos los platos, felicidades bro");
    }else{
         //SE ELIMINAN LOS TRES TRASTES DE LA PILA CON EL METODO DE ELIMINAR NODO
    eliminarNodo();
    eliminarNodo();
    eliminarNodo();
   
    }
  
}



public void copasSucias(){
   NodoPila aux = cima;
   int contador=0;
   String mensaje1="";
 
        while(aux != null){
            contador++;
            if (aux.traste.tipo=="Copa") {
         
                mensaje1=mensaje1+("\n"+contador+" "+"|\t"+" "+ aux.traste.tipo+" "+ "\t|");
            }
            
            
            aux = aux.getSiguiente();
        }
       
        JOptionPane.showMessageDialog(null, mensaje1);
}




public void platosSucios(){
        //NOS PERMITE VER LOS PLATOS SUCIOS EN LA PILA RECORRIENDO TODA LA PILA
        
   NodoPila aux = cima;
   int contador=0;
   String mensaje1="";
 
        while(aux != null){
            contador++;
            if (aux.traste.tipo=="Plato") {
         
                mensaje1=mensaje1+("\n"+contador+" "+"|\t"+" "+ aux.traste.tipo+" "+ "\t|");
            }
            
            
            aux = aux.getSiguiente();
        }
       
        JOptionPane.showMessageDialog(null, mensaje1);
}



public void vasosSucios(){
    //NOS PERMITE VER LOS VASOS SUCIOS EN LA PILA RECORRIENDO TODA LA PILA
    
   NodoPila aux = cima;
   int contador=0;
   String mensaje1="";
 
        while(aux != null){
            contador++;
            if (aux.traste.tipo=="Vaso") {
                
                mensaje1=mensaje1+("\n"+contador+" "+"|\t"+" "+ aux.traste.tipo+" "+ "\t|");
            }
            
            
            aux = aux.getSiguiente();
        }
       
        JOptionPane.showMessageDialog(null, mensaje1);
}



public void cubiertosSucios(){
        //NOS PERMITE VER LOS CUBIERTOS SUCIOS EN LA PILA RECORRIENDO TODA LA PILA
        
   NodoPila aux = cima;
   int contador=0;
   String mensaje1="";
 
        while(aux != null){
            contador++;
            if (aux.traste.tipo=="Cuchillo"||aux.traste.tipo=="Cuchara"||aux.traste.tipo=="Tenedor") {
         
                mensaje1=mensaje1+("\n"+contador+" "+"|\t"+" "+ aux.traste.tipo+" "+ "\t|");
            }
            
            
            aux = aux.getSiguiente();
        }
       
        JOptionPane.showMessageDialog(null, mensaje1);
}
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Regresar = new javax.swing.JButton();
        totalSucios = new javax.swing.JButton();
        lavar = new javax.swing.JButton();
        VasosSucios = new javax.swing.JButton();
        cubiertosSucios = new javax.swing.JButton();
        poder = new javax.swing.JButton();
        platoSucio = new javax.swing.JButton();
        Ayudar = new javax.swing.JButton();
        empezar = new javax.swing.JButton();
        copasSucias = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Lava Platos");
        setBackground(new java.awt.Color(0, 0, 255));
        setForeground(new java.awt.Color(251, 104, 20));

        jPanel1.setBackground(new java.awt.Color(50, 186, 212));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Regresar.setBackground(new java.awt.Color(255, 0, 0));
        Regresar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setText("Regresar");
        Regresar.setFocusPainted(false);
        Regresar.setFocusable(false);
        Regresar.setRequestFocusEnabled(false);
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        jPanel1.add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 30));

        totalSucios.setBackground(new java.awt.Color(246, 170, 0));
        totalSucios.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        totalSucios.setForeground(new java.awt.Color(255, 255, 255));
        totalSucios.setText("Ver total por lavar");
        totalSucios.setEnabled(false);
        totalSucios.setFocusPainted(false);
        totalSucios.setFocusable(false);
        totalSucios.setRequestFocusEnabled(false);
        totalSucios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalSuciosActionPerformed(evt);
            }
        });
        jPanel1.add(totalSucios, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 210, -1, -1));

        lavar.setBackground(new java.awt.Color(246, 170, 0));
        lavar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lavar.setForeground(new java.awt.Color(255, 255, 255));
        lavar.setText("Lavar traste ");
        lavar.setEnabled(false);
        lavar.setFocusPainted(false);
        lavar.setFocusable(false);
        lavar.setRequestFocusEnabled(false);
        lavar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lavarActionPerformed(evt);
            }
        });
        jPanel1.add(lavar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, -1, -1));

        VasosSucios.setBackground(new java.awt.Color(246, 170, 0));
        VasosSucios.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        VasosSucios.setForeground(new java.awt.Color(255, 255, 255));
        VasosSucios.setText("Ver vasos sucios");
        VasosSucios.setEnabled(false);
        VasosSucios.setFocusPainted(false);
        VasosSucios.setFocusable(false);
        VasosSucios.setRequestFocusEnabled(false);
        VasosSucios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VasosSuciosActionPerformed(evt);
            }
        });
        jPanel1.add(VasosSucios, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, 160, -1));

        cubiertosSucios.setBackground(new java.awt.Color(246, 170, 0));
        cubiertosSucios.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        cubiertosSucios.setForeground(new java.awt.Color(255, 255, 255));
        cubiertosSucios.setText("Ver cubiertos sucios");
        cubiertosSucios.setEnabled(false);
        cubiertosSucios.setFocusPainted(false);
        cubiertosSucios.setFocusable(false);
        cubiertosSucios.setRequestFocusEnabled(false);
        cubiertosSucios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cubiertosSuciosActionPerformed(evt);
            }
        });
        jPanel1.add(cubiertosSucios, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 170, -1, -1));

        poder.setBackground(new java.awt.Color(246, 170, 0));
        poder.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        poder.setForeground(new java.awt.Color(255, 255, 255));
        poder.setText("Usar poder");
        poder.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        poder.setEnabled(false);
        poder.setFocusPainted(false);
        poder.setFocusable(false);
        poder.setRequestFocusEnabled(false);
        poder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                poderActionPerformed(evt);
            }
        });
        jPanel1.add(poder, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, -1, -1));

        platoSucio.setBackground(new java.awt.Color(246, 170, 0));
        platoSucio.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        platoSucio.setForeground(new java.awt.Color(255, 255, 255));
        platoSucio.setText("Ver platos sucios");
        platoSucio.setEnabled(false);
        platoSucio.setFocusPainted(false);
        platoSucio.setFocusable(false);
        platoSucio.setRequestFocusEnabled(false);
        platoSucio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                platoSucioActionPerformed(evt);
            }
        });
        jPanel1.add(platoSucio, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 90, 160, -1));

        Ayudar.setBackground(new java.awt.Color(255, 0, 0));
        Ayudar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Ayudar.setForeground(new java.awt.Color(255, 255, 255));
        Ayudar.setText("Ayuda");
        Ayudar.setFocusPainted(false);
        Ayudar.setFocusable(false);
        Ayudar.setRequestFocusEnabled(false);
        Ayudar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AyudarActionPerformed(evt);
            }
        });
        jPanel1.add(Ayudar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, -1, 30));

        empezar.setBackground(new java.awt.Color(255, 0, 0));
        empezar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        empezar.setForeground(new java.awt.Color(255, 255, 255));
        empezar.setText("Empezar");
        empezar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        empezar.setFocusPainted(false);
        empezar.setRequestFocusEnabled(false);
        empezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empezarActionPerformed(evt);
            }
        });
        jPanel1.add(empezar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, 30));

        copasSucias.setBackground(new java.awt.Color(246, 170, 0));
        copasSucias.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        copasSucias.setForeground(new java.awt.Color(255, 255, 255));
        copasSucias.setText("Ver copas sucias");
        copasSucias.setEnabled(false);
        copasSucias.setFocusPainted(false);
        copasSucias.setFocusable(false);
        copasSucias.setRequestFocusEnabled(false);
        copasSucias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copasSuciasActionPerformed(evt);
            }
        });
        jPanel1.add(copasSucias, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 50, 160, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\50662\\Downloads\\ImagenesProyectoJava\\pila4.jpeg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 310));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        VentanaPrincipal ventanaPrincipal1=new VentanaPrincipal();
        ventanaPrincipal1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegresarActionPerformed

    private void totalSuciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalSuciosActionPerformed
        Mostrar();
    }//GEN-LAST:event_totalSuciosActionPerformed

    private void lavarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lavarActionPerformed
        eliminarNodo();
    }//GEN-LAST:event_lavarActionPerformed

    private void VasosSuciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VasosSuciosActionPerformed
        vasosSucios();
    }//GEN-LAST:event_VasosSuciosActionPerformed

    private void cubiertosSuciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cubiertosSuciosActionPerformed
        cubiertosSucios();
    }//GEN-LAST:event_cubiertosSuciosActionPerformed

    private void poderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_poderActionPerformed
        if (contPoder==3) {
            
            Poder();
           contPoder=0;
           poder.setEnabled(false);
           
        }
    }//GEN-LAST:event_poderActionPerformed

    private void platoSucioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_platoSucioActionPerformed
       platosSucios();
    }//GEN-LAST:event_platoSucioActionPerformed

    private void AyudarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AyudarActionPerformed
        AyudaLavaPlatos ayudaLavaPlatos=new AyudaLavaPlatos();
        ayudaLavaPlatos.setVisible(true);
       
    }//GEN-LAST:event_AyudarActionPerformed

    private void empezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empezarActionPerformed
       agregar("Plato");
       agregar("Plato");
        agregar("Cuchillo");
       agregar("Plato");
       agregar("Vaso");
       agregar("Plato");
        agregar("Vaso");
        agregar("Tenedor");
        agregar("Vaso");
        agregar("Copa");
        agregar("Cuchillo");
        agregar("Cuchara");
        agregar("Tenedor");
        agregar("Cuchillo");
        agregar("Cuchara");
        platoSucio.setEnabled(true);
        lavar.setEnabled(true);
        cubiertosSucios.setEnabled(true);
        VasosSucios.setEnabled(true);
        totalSucios.setEnabled(true);
        empezar.setEnabled(false);
        copasSucias.setEnabled(true);
    }//GEN-LAST:event_empezarActionPerformed

    private void copasSuciasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copasSuciasActionPerformed
        copasSucias();
    }//GEN-LAST:event_copasSuciasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LavaplatosVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LavaplatosVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LavaplatosVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LavaplatosVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LavaplatosVent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ayudar;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton VasosSucios;
    private javax.swing.JButton copasSucias;
    private javax.swing.JButton cubiertosSucios;
    private javax.swing.JButton empezar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton lavar;
    private javax.swing.JButton platoSucio;
    private javax.swing.JButton poder;
    private javax.swing.JButton totalSucios;
    // End of variables declaration//GEN-END:variables
}
