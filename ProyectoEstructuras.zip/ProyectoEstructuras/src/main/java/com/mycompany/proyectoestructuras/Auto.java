/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class Auto {
    public String tipoAuto;
    public int año;
    public String tipoCombustible;

    

    public Auto() {
    }

    public Auto(String tipoAuto, int año, String tipoCombustible) {
        this.tipoAuto = tipoAuto;
        this.año = año;
        this.tipoCombustible = tipoCombustible;
    }

    public String getTipoAuto() {
        return tipoAuto;
    }

    public void setTipoAuto(String tipoAuto) {
        this.tipoAuto = tipoAuto;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

   
    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

   
    
}
