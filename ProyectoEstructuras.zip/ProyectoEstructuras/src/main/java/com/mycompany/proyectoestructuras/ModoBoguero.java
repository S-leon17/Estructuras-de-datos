/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyectoestructuras;

import com.mycompany.proyectoestructuras.VentanaPrincipal;
import com.mycompany.proyectoestructuras.Materiales;
import com.mycompany.proyectoestructuras.NodoMaterial;
import javax.swing.JOptionPane;


public class ModoBoguero extends javax.swing.JFrame {
public NodoMaterial cabeza;
    public NodoMaterial ultimo;
   
    public ModoBoguero() {
        initComponents();
        this.cabeza=null;
        
    }

    
    public void acomodar(Materiales material){
        //ESTE METODO GUARDA LOS MATERIALES EN LA BODEGA
        if (cabeza==null) {
            
            cabeza=new NodoMaterial(material);
            ultimo=cabeza;
            ultimo.setSiguiente(cabeza);
            //SI LA CABEZA ES NULA ENTONCES EL NUEVO NODO SE CONVIERTE EN CABEZA, EN ULTIMO Y EL ULTIMO SIGUIENTE APUNTARA A LA CABEZA
            
        }else if(material.getId()<cabeza.getMaterial().getId()){
            
            NodoMaterial aux=new NodoMaterial(material);
            aux.setSiguiente(cabeza);
            cabeza=aux;
            ultimo.setSiguiente(cabeza);
            //SI EL ID DEL PRODUCTO A INGRESAR ES MENOR AL DE LA CABEZA  ENTONCES SE CONVIERTE EN LA CABEZA, LA CABEZA SIGUIENTE APUNTA A LA CABEZA ANTERIOR Y EL ULTIMO SIGUIENTE 
            //APUNTA A LA NUEVA CABEZA 
            
      
        }else if(ultimo.getMaterial().getId()<=material.getId()){
            
            ultimo.setSiguiente(new NodoMaterial(material));
            ultimo=ultimo.getSiguiente();
            ultimo.setSiguiente(cabeza);
            //SI EL ULTIMO PRODUCTO TIENE UN ID MENOR O IGUAL AL NUEVO PRODUCTO EL ULTIMO SIGUIENTE ES EL NUEVO NODO
            //EL ULTIMO SE CONVIERTE EN EL NUEVO PRODUCTO Y EL NUEVO ULTIMO SIGUIENTE APUNTARA A LA CABEZA
            
        }else{
            
            NodoMaterial aux=cabeza;
            while (aux.getSiguiente().getMaterial().getId()<material.getId()) {
               aux=aux.getSiguiente();
                
            }
            NodoMaterial temp=new NodoMaterial(material);
            temp.setSiguiente(aux.getSiguiente());
            aux.setSiguiente(temp);
            
            //SI SE DEBE INSERTAR AL MEDIO SE RECORRE TODA LA LISTA HASTA ENCONTAR EL ID MAYOR 
            
        }
    }
    
    
      public void Mostrar(){
    //MOSTRAR LOS PRODUCTOS GUARDADOS CON SU ID
   NodoMaterial aux = cabeza;
          if (cabeza!=null) {
              while(true==true){
    int seleccion=JOptionPane.showOptionDialog(null, "Id: "+aux.material.id+"   Material: "+aux.material.material,
  "Selector de opciones",JOptionPane.YES_NO_CANCEL_OPTION,
   JOptionPane.QUESTION_MESSAGE,null,// null para icono por defecto.
  new Object[] { "Siguiente", "Salir",  },"opcion 1");
  if(seleccion==1){
      break;
  }
  aux=aux.siguiente;
 }

}else{
              JOptionPane.showMessageDialog(null,"No tienes productos en la bodega...");
          }  
}  
      
public void buscar(){
    //Nos permite buscar por medio del id del producto a guardar recorriendo toda la lista
    
    String producto=JOptionPane.showInputDialog("Ingrese el nombre del producto a buscar");
    NodoMaterial aux=cabeza;
    int indicador=0;
    while(true==true){

        if (producto.equals(aux.material.material)) {
            JOptionPane.showMessageDialog(null, "Tu producto se encontro en la bodega: "+"\n"+"Id: "+aux.material.id+"\n"+"Producto: "+ aux.material.material);
            indicador=1;
            break;
        }
        if(aux==ultimo){
            
            break;
        }
        aux=aux.siguiente;
    }
        
   
        
    if (indicador==0) {
         JOptionPane.showMessageDialog(null, "Tu producto no se encontro en la bodega");
    }
}


public void eliminar(int dato){
    
   NodoMaterial p=cabeza;
   NodoMaterial aux;
   //creamos 2 nodos ayudantes
   
   boolean encontrado=false;
   //nos ayudara a ver si se encuentra el id
   
    if (cabeza!=null) {
        //si la cabeza es nula
        
        while(p.siguiente!=cabeza && !encontrado){
            //hasta que p siguiente sea diferente a la cabeza de la lista y no se haya encontrado el id aun
            
            aux=p.siguiente;
            
            encontrado= (aux.getMaterial().id ==dato);
            //si el id de aux es igual al que buscamos entonces encontrado pasa a true
            
            if (!encontrado) {
                //si encontrado es false 
                
                p=p.getSiguiente();
                //p va a ir avanzando por la lista
                
            }
        }
        
        aux=p.getSiguiente();
        encontrado=(aux.getMaterial().id ==dato);
        if(encontrado){
            //si se encontro el id buscado 
            
            if (cabeza==cabeza.getSiguiente()) {
                //si solo hay un nodo y es la cabeza
                cabeza=null;
                //se borra el nodo de la cabeza
                
            }else{
                // si queremos eliminar otro que no sea caabeza
                
                if (aux==cabeza) {
                    cabeza=p;
                }
                p.setSiguiente(aux.getSiguiente());
                aux=null;
            }
        }
    }
    
    }

        
      
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Llevar = new javax.swing.JButton();
        empezar = new javax.swing.JButton();
        regresar = new javax.swing.JButton();
        Ayuda = new javax.swing.JButton();
        BuscarMaterial = new javax.swing.JButton();
        verMaterial = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bodeguero");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(142, 80, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Llevar.setBackground(new java.awt.Color(246, 170, 0));
        Llevar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Llevar.setForeground(new java.awt.Color(255, 255, 255));
        Llevar.setText("Llevar a cocina");
        Llevar.setEnabled(false);
        Llevar.setFocusPainted(false);
        Llevar.setFocusable(false);
        Llevar.setRequestFocusEnabled(false);
        Llevar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LlevarActionPerformed(evt);
            }
        });
        jPanel1.add(Llevar, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 246, -1, -1));

        empezar.setBackground(new java.awt.Color(255, 0, 0));
        empezar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        empezar.setForeground(new java.awt.Color(255, 255, 255));
        empezar.setText("Empezar");
        empezar.setFocusPainted(false);
        empezar.setFocusable(false);
        empezar.setRequestFocusEnabled(false);
        empezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empezarActionPerformed(evt);
            }
        });
        jPanel1.add(empezar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 110, 30));

        regresar.setBackground(new java.awt.Color(255, 0, 0));
        regresar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(255, 255, 255));
        regresar.setText("Regresar");
        regresar.setFocusPainted(false);
        regresar.setFocusable(false);
        regresar.setRequestFocusEnabled(false);
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });
        jPanel1.add(regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 30));

        Ayuda.setBackground(new java.awt.Color(255, 0, 0));
        Ayuda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Ayuda.setForeground(new java.awt.Color(255, 255, 255));
        Ayuda.setText("Ayuda");
        Ayuda.setFocusPainted(false);
        Ayuda.setFocusable(false);
        Ayuda.setRequestFocusEnabled(false);
        Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AyudaActionPerformed(evt);
            }
        });
        jPanel1.add(Ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 6, -1, 30));

        BuscarMaterial.setBackground(new java.awt.Color(246, 170, 0));
        BuscarMaterial.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        BuscarMaterial.setForeground(new java.awt.Color(255, 255, 255));
        BuscarMaterial.setText("Buscar Procuctos");
        BuscarMaterial.setEnabled(false);
        BuscarMaterial.setFocusPainted(false);
        BuscarMaterial.setFocusable(false);
        BuscarMaterial.setRequestFocusEnabled(false);
        BuscarMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarMaterialActionPerformed(evt);
            }
        });
        jPanel1.add(BuscarMaterial, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 134, 160, -1));

        verMaterial.setBackground(new java.awt.Color(246, 170, 0));
        verMaterial.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        verMaterial.setForeground(new java.awt.Color(255, 255, 255));
        verMaterial.setText("Ver Productos");
        verMaterial.setEnabled(false);
        verMaterial.setFocusPainted(false);
        verMaterial.setFocusable(false);
        verMaterial.setRequestFocusEnabled(false);
        verMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verMaterialActionPerformed(evt);
            }
        });
        jPanel1.add(verMaterial, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 94, 160, -1));

        guardar.setBackground(new java.awt.Color(246, 170, 0));
        guardar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        guardar.setForeground(new java.awt.Color(255, 255, 255));
        guardar.setText("Guardar Productos");
        guardar.setEnabled(false);
        guardar.setFocusPainted(false);
        guardar.setFocusable(false);
        guardar.setRequestFocusEnabled(false);
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        jPanel1.add(guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 240, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\50662\\Downloads\\ImagenesProyectoJava\\Bodega.jpeg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, -4, 530, 300));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 530, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void empezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empezarActionPerformed
       Llevar.setEnabled(true);
        verMaterial.setEnabled(true);
         BuscarMaterial.setEnabled(true);
         guardar.setEnabled(true);
         empezar.setEnabled(false);
    }//GEN-LAST:event_empezarActionPerformed

    private void LlevarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LlevarActionPerformed
        if (cabeza!=null) {
            int dato=Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el id del producto a llevar a la bodega: "));
             eliminar(dato);
        }else{
           JOptionPane.showMessageDialog(null, "No hay nada que eliminar");
        }
       
    }//GEN-LAST:event_LlevarActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
       NodoMaterial aux=cabeza;
         int id=Integer.parseInt(JOptionPane.showInputDialog(null,"Digita el id del producto: "));
                 String producto=JOptionPane.showInputDialog(null,"Digita producto a ingresar: ");
        while (true==true) {
            if (cabeza!=null) {
                aux=aux.siguiente;
                
                if (id!=aux.material.id) {
                break;
                
            }else{
                JOptionPane.showMessageDialog(null, "Has intentado ingresar un producto en un lugar ya lleno, por favor ingresa otro id");
                 id=Integer.parseInt(JOptionPane.showInputDialog(null,"Digita el id del producto: "));
                 producto=JOptionPane.showInputDialog(null,"Digita producto a ingresar: ");
            }
            
            }else{
                break;
            }
            
            
        }
        acomodar(new Materiales(id,producto));
    }//GEN-LAST:event_guardarActionPerformed

    private void verMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verMaterialActionPerformed
       
        
        Mostrar();
    }//GEN-LAST:event_verMaterialActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
       VentanaPrincipal ventanaPrincipal1= new VentanaPrincipal();
       ventanaPrincipal1.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_regresarActionPerformed

    private void BuscarMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarMaterialActionPerformed
        if (cabeza!=null) {
            buscar();
        }else{
            JOptionPane.showMessageDialog(null, "No hay productos en la bodega...");
        }
        
    }//GEN-LAST:event_BuscarMaterialActionPerformed

    private void AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AyudaActionPerformed
        AyudaBodeguero ayudaBodeguero=new AyudaBodeguero();
        ayudaBodeguero.setVisible(true);
    }//GEN-LAST:event_AyudaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModoBoguero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModoBoguero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModoBoguero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModoBoguero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModoBoguero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ayuda;
    private javax.swing.JButton BuscarMaterial;
    private javax.swing.JButton Llevar;
    private javax.swing.JButton empezar;
    private javax.swing.JButton guardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton regresar;
    private javax.swing.JButton verMaterial;
    // End of variables declaration//GEN-END:variables
}
