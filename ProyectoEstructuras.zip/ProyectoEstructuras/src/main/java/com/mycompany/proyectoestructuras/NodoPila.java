/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class NodoPila {
    //declaramos los atributos del nodo 
    public Traste traste;
    public NodoPila siguiente;

   public  NodoPila(){  
    //nuestro constructor del nodo
       this.siguiente=null;
   }
 
 //los getters and setters
    public Traste getTraste() {
        return traste;
    }

    public void setTraste(Traste traste) {
        this.traste = traste;
    }

    public NodoPila getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoPila siguiente) {
        this.siguiente = siguiente;
    }
    
   
    
    
}
