/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuras;

/**
 *
 * @author 50662
 */
public class NodoPlatillos {
public NodoPlatillos raiz;
public NodoPlatillos hijoIzq;
public NodoPlatillos hijoDer;
public int llave;
public String Nombre;
public int indice;

   
   public NodoPlatillos(int index){
       llave=index;
       hijoDer=null;
       hijoIzq=null;
       raiz=null;
       Nombre=null;
       indice=0;
   }









}
