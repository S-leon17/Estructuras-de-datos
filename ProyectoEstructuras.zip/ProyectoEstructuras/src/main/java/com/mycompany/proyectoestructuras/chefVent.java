/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyectoestructuras;

import javax.swing.JOptionPane;


public class chefVent extends javax.swing.JFrame {
public NodoPlatillos raiz;
//creamos una variable para mostrar un mensaje con varios nodos a la vez
String mensaje="";
String mensaje1="";
String mensaje2="";
int cuenta=0;
int indice=0;


    public chefVent() {
        initComponents();
        this.raiz=null;
    }
    
    
    
    
public void inOrdenIndice(){
        if (raiz!=null){
            //si la raiz no esta vacia se llama al metodo inOrdenRecorrerIndice
            inOrdenRecorrerIndice(raiz);
            
        }else{
            //si no cuenta con una raiz se mustra este mensaje
             JOptionPane.showMessageDialog(null, "El menú esta vacio...");
        }
    }
   public void inOrdenRecorrerIndice(NodoPlatillos nodo){
       //si el nodo no es null entonces se recorre el lado izquierdo del arbol y luego el lado derecho de forma recursiva y se guarda cada uno de los nodos en la variable mensaje
       
       if (nodo!=null){
          
           inOrdenRecorrerIndice(nodo.hijoIzq);
           inOrdenRecorrerIndice(nodo.hijoDer);
        mensaje1+="| Id: "+nodo.indice+"  Nombre: "+nodo.Nombre+"|\n";
   }
  
   }  

public void insertar(int precio, String platillo, int indice){
    //Se crea el nodo que se va a insertar en el arbol
    NodoPlatillos nodo=new NodoPlatillos(precio);
    //Se le asigna el nombre al nodo
    nodo.Nombre=platillo;
    nodo.indice=indice;
    //si no hay una raiz y se agrega un nuevo nodo se convierte en la raiz
    if(raiz==null){
        raiz=nodo;
        //si ya hay una raiz en el arbol
    }else{
        NodoPlatillos aux =raiz; 
              //se crea un nodo auxiliar que nos ayudara a recorrer el arbol y acomodarse en la posicion que deba
        while(aux!=null){
            
            nodo.raiz=aux;
            if(nodo.llave>=aux.llave){
                //si la llave del nodo es mayor entonces que el nodo aux se dirija a la derecha del arbol
               aux=aux.hijoDer;
            }else{
                //si es menor que se dirija a la izquierda 
                aux=aux.hijoIzq;
            }
            
            
        }
        //si la llave del nodo a insertar es menor que la llave del nodo raiz
      if(nodo.llave<nodo.raiz.llave){ 
          //inserte el nodo a insertar a la izquierda del nodo raiz
      nodo.raiz.hijoIzq=nodo;
      
      }else{
          // si no es menor que la llave del nodo raiz inserte a la derecha del nodo raiz
          nodo.raiz.hijoDer=nodo;
      }  
        
    }
    cuenta++;
}

public void eliminar(int eliminador){
    NodoPlatillos aux=raiz;
    NodoPlatillos padre=raiz;
    boolean esHijoIzq=true;
    while(aux.indice!=eliminador){
        padre=aux;
        if (eliminador<aux.indice) {
            esHijoIzq=true;
            aux=aux.hijoIzq;
            
        }if (aux==null) {
           JOptionPane.showMessageDialog(null, "Lo sentimos, pero ese numero de orden no esxiste...");
        }
        else{
            esHijoIzq=false;
            aux=aux.hijoDer;
        }
        
    }
    if (aux.hijoIzq==null && aux.hijoDer==null)  {
        
        if (aux==raiz) {
            raiz=null;
        }else if(esHijoIzq){
            
            padre.hijoIzq=null;
           
        } else{
                    padre.hijoDer=null;
                    }
        
    }else if(aux.hijoDer==null){
        
          if (aux==raiz) {
              
            raiz=aux.hijoIzq;
            
        }else if(esHijoIzq){
            
            padre.hijoIzq=aux.hijoIzq;
           
        } else{
                    padre.hijoDer=aux.hijoIzq;
                    
                    }
    }else if(aux.hijoIzq==null){
        
               if (aux==raiz) {
                   
            raiz=aux.hijoDer;
            
        }else if(esHijoIzq){
            
            padre.hijoIzq=aux.hijoDer;
           
        } else{
            
                    padre.hijoDer=aux.hijoDer;
                    
                    }               
    }else{
        NodoPlatillos reemplazo=obtenerNodoReemplazo(aux);
        
        if (aux==raiz) {
            raiz=reemplazo;
        }else if(esHijoIzq){
            padre.hijoIzq=reemplazo;
        }else{
            padre.hijoDer=reemplazo;
        }
        reemplazo.hijoIzq=aux.hijoIzq;
       
    }
   cuenta--;
   
}


public NodoPlatillos obtenerNodoReemplazo(NodoPlatillos nodoReemp){
    
    NodoPlatillos reemplazarPadre=nodoReemp;
    NodoPlatillos reemplazo=nodoReemp;
    NodoPlatillos aux= nodoReemp.hijoDer;
    while(aux!=null){
        reemplazarPadre=reemplazo;
        reemplazo=aux;
        aux=aux.hijoIzq;
        
    }
    if (reemplazo!=nodoReemp.hijoDer) {
        reemplazarPadre.hijoIzq=reemplazo.hijoDer;
        reemplazo.hijoDer=nodoReemp.hijoDer;
    }
    
    return reemplazo;
}




  
public void buscarPlatillo(int precio){
    //Se busca un plato en el menu por medio del precio
    NodoPlatillos aux=raiz;
    while(aux.llave!=precio){
        if (precio<aux.llave) {
            aux=aux.hijoIzq;
        }else{
            aux=aux.hijoDer;
        }
        if (aux==null) {
            JOptionPane.showMessageDialog(null, "No se encontro un platillo con ese precio...");
        }
    }
    JOptionPane.showMessageDialog(null, "Se ha encontrado un plato con ese precio en el menú!" +"\n"+"|Nombre: "+aux.Nombre+"|");
    }
 
     
   
    
    





 public void inOrden(){
        if (raiz!=null){
            //si la raiz no esta vacia se llama al metodo inOrdenRecorrer
            inOrdenRecorrer(raiz);
            
        }else{
            //si no cuenta con una raiz se mustra este emensaje
             JOptionPane.showMessageDialog(null, "El menú esta vacio...");
        }
    }
   public void inOrdenRecorrer(NodoPlatillos nodo){
       //si el nodo no es null entonces se recorre el lado izquierdo del arbol y luego el lado derecho de forma recursiva y se guarda cada uno de los nodos en la variable mensaje
       
       if (nodo!=null){
           mensaje+=" Precio: "+nodo.llave+" | "+nodo.Nombre+"\n";
           inOrdenRecorrer(nodo.hijoIzq);
           inOrdenRecorrer(nodo.hijoDer);
       
   }
  
   }
 public void menorValor() {
     //este metodo se dirige hasta el nodo mas izquierdo del arbol para averiguar el de la llave mas baja
        if (raiz!=null) {
            NodoPlatillos reco=raiz;
            while (reco.hijoIzq!=null)
                reco=reco.hijoIzq;
            JOptionPane.showMessageDialog(null, "El plato más barato del menú es "+reco.Nombre);
        }
    }
    
    public void mayorValor() {
          //este metodo se dirige hasta el nodo mas derecho del arbol para averiguar el de la llave mas alta
        if (raiz!=null) {
            NodoPlatillos reco=raiz;
            while (reco.hijoDer!=null)
                reco=reco.hijoDer;
            JOptionPane.showMessageDialog(null, "El plato más caro del menú es : "+reco.Nombre);
        }
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        precioBajo1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        precioAlto = new javax.swing.JButton();
        agregarPlatillo = new javax.swing.JButton();
        eliminarPlatillo = new javax.swing.JButton();
        verMenu = new javax.swing.JButton();
        precioBajo = new javax.swing.JButton();
        regresar = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        empezar = new javax.swing.JButton();
        buscarPorPrecio = new javax.swing.JButton();
        VerId = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        precioBajo1.setBackground(new java.awt.Color(246, 170, 0));
        precioBajo1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        precioBajo1.setForeground(new java.awt.Color(255, 255, 255));
        precioBajo1.setText("Plato más economico");
        precioBajo1.setEnabled(false);
        precioBajo1.setFocusPainted(false);
        precioBajo1.setFocusable(false);
        precioBajo1.setRequestFocusEnabled(false);
        precioBajo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioBajo1ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chef");
        setBackground(new java.awt.Color(0, 0, 255));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        precioAlto.setBackground(new java.awt.Color(246, 170, 0));
        precioAlto.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        precioAlto.setForeground(new java.awt.Color(255, 255, 255));
        precioAlto.setText("Plato más caro");
        precioAlto.setEnabled(false);
        precioAlto.setFocusPainted(false);
        precioAlto.setFocusable(false);
        precioAlto.setRequestFocusEnabled(false);
        precioAlto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioAltoActionPerformed(evt);
            }
        });
        jPanel1.add(precioAlto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, 30));

        agregarPlatillo.setBackground(new java.awt.Color(246, 170, 0));
        agregarPlatillo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        agregarPlatillo.setForeground(new java.awt.Color(255, 255, 255));
        agregarPlatillo.setText("Agregar al Menú");
        agregarPlatillo.setEnabled(false);
        agregarPlatillo.setFocusPainted(false);
        agregarPlatillo.setFocusable(false);
        agregarPlatillo.setRequestFocusEnabled(false);
        agregarPlatillo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarPlatilloActionPerformed(evt);
            }
        });
        jPanel1.add(agregarPlatillo, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 240, -1, 30));

        eliminarPlatillo.setBackground(new java.awt.Color(246, 170, 0));
        eliminarPlatillo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        eliminarPlatillo.setForeground(new java.awt.Color(255, 255, 255));
        eliminarPlatillo.setText("Eliminar del Menú");
        eliminarPlatillo.setEnabled(false);
        eliminarPlatillo.setFocusPainted(false);
        eliminarPlatillo.setFocusable(false);
        eliminarPlatillo.setRequestFocusEnabled(false);
        eliminarPlatillo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarPlatilloActionPerformed(evt);
            }
        });
        jPanel1.add(eliminarPlatillo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, -1, 30));

        verMenu.setBackground(new java.awt.Color(246, 170, 0));
        verMenu.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        verMenu.setForeground(new java.awt.Color(255, 255, 255));
        verMenu.setText("Visualizar Menú");
        verMenu.setEnabled(false);
        verMenu.setFocusPainted(false);
        verMenu.setFocusable(false);
        verMenu.setRequestFocusEnabled(false);
        verMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verMenuActionPerformed(evt);
            }
        });
        jPanel1.add(verMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, -1, 30));

        precioBajo.setBackground(new java.awt.Color(246, 170, 0));
        precioBajo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        precioBajo.setForeground(new java.awt.Color(255, 255, 255));
        precioBajo.setText("Plato más economico");
        precioBajo.setEnabled(false);
        precioBajo.setFocusPainted(false);
        precioBajo.setFocusable(false);
        precioBajo.setRequestFocusEnabled(false);
        precioBajo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioBajoActionPerformed(evt);
            }
        });
        jPanel1.add(precioBajo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, 30));

        regresar.setBackground(new java.awt.Color(255, 0, 0));
        regresar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(255, 255, 255));
        regresar.setText("Regresar");
        regresar.setFocusPainted(false);
        regresar.setFocusable(false);
        regresar.setRequestFocusEnabled(false);
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });
        jPanel1.add(regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 30));

        jButton7.setBackground(new java.awt.Color(255, 0, 0));
        jButton7.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Ayuda");
        jButton7.setFocusPainted(false);
        jButton7.setFocusable(false);
        jButton7.setRequestFocusEnabled(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, -1, 30));

        empezar.setBackground(new java.awt.Color(255, 0, 0));
        empezar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        empezar.setForeground(new java.awt.Color(255, 255, 255));
        empezar.setText("Empezar");
        empezar.setFocusPainted(false);
        empezar.setFocusable(false);
        empezar.setRequestFocusEnabled(false);
        empezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empezarActionPerformed(evt);
            }
        });
        jPanel1.add(empezar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, -1, 30));

        buscarPorPrecio.setBackground(new java.awt.Color(246, 170, 0));
        buscarPorPrecio.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        buscarPorPrecio.setForeground(new java.awt.Color(255, 255, 255));
        buscarPorPrecio.setText("Buscar por precio");
        buscarPorPrecio.setEnabled(false);
        buscarPorPrecio.setFocusPainted(false);
        buscarPorPrecio.setFocusable(false);
        buscarPorPrecio.setRequestFocusEnabled(false);
        buscarPorPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarPorPrecioActionPerformed(evt);
            }
        });
        jPanel1.add(buscarPorPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 160, 210, 30));

        VerId.setBackground(new java.awt.Color(246, 170, 0));
        VerId.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        VerId.setForeground(new java.awt.Color(255, 255, 255));
        VerId.setText("Ver indices del Menú");
        VerId.setEnabled(false);
        VerId.setFocusPainted(false);
        VerId.setFocusable(false);
        VerId.setRequestFocusEnabled(false);
        VerId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerIdActionPerformed(evt);
            }
        });
        jPanel1.add(VerId, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, -1, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\50662\\Downloads\\ImagenesProyectoJava\\chef.jpg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void precioAltoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioAltoActionPerformed
        mayorValor();
    }//GEN-LAST:event_precioAltoActionPerformed

    private void eliminarPlatilloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarPlatilloActionPerformed
        if (raiz==null) {
            JOptionPane.showMessageDialog(null, "No hay nada que eliminar del menú");
        }else{
            int eliminador=Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el id del plato que desea sacar del menú"));
        eliminar(eliminador);
        }
        
    }//GEN-LAST:event_eliminarPlatilloActionPerformed

    private void verMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verMenuActionPerformed
       
        if(raiz!=null){
         //si la raiz no es nula se llama al metodo inOrden y se mustra la variable mensaje y luego se limpia la misma
          inOrden();
          JOptionPane.showMessageDialog(null, mensaje);
          mensaje="";
        }else{
            JOptionPane.showMessageDialog(null, "Lo sentimos pero no has agregado nada al menu...");
        }
        
    }//GEN-LAST:event_verMenuActionPerformed

    private void precioBajoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioBajoActionPerformed
        menorValor();
    }//GEN-LAST:event_precioBajoActionPerformed

    private void agregarPlatilloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarPlatilloActionPerformed
        //se solicitan los parametros del metodo ingresar 
        int precio=Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el precio del nuevo platillo a agregar: "));
        String nom=JOptionPane.showInputDialog(null, "Digite el nombre del nuevo platillo a agregar: ");
        indice++;
        insertar(precio, nom,indice);

    }//GEN-LAST:event_agregarPlatilloActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        VentanaPrincipal ventanaPrincipal= new VentanaPrincipal();
        ventanaPrincipal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_regresarActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        AyudaChef ayudaChef=new AyudaChef();
        ayudaChef.setVisible(true);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void empezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empezarActionPerformed
        verMenu.setEnabled(true);
        precioAlto.setEnabled(true);
        buscarPorPrecio.setEnabled(true);
        precioBajo.setEnabled(true);
        agregarPlatillo.setEnabled(true);
        eliminarPlatillo.setEnabled(true);
        VerId.setEnabled(true);
        empezar.setEnabled(false);
    }//GEN-LAST:event_empezarActionPerformed

    private void buscarPorPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarPorPrecioActionPerformed
         int precioPlato=Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero de platillo que desea buscar"));
        buscarPlatillo(precioPlato);
    }//GEN-LAST:event_buscarPorPrecioActionPerformed

    private void precioBajo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioBajo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precioBajo1ActionPerformed

    private void VerIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerIdActionPerformed
          if(raiz!=null){
         //si la raiz no es nula se llama al metodo inOrden y se mustra la variable mensaje y luego se limpia la misma
          inOrdenIndice();
          JOptionPane.showMessageDialog(null, mensaje1);
          mensaje1="";
        }else{
            JOptionPane.showMessageDialog(null, "Lo sentimos pero no has agregado nada al menu...");
        }
        
                                       
    }//GEN-LAST:event_VerIdActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(chefVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(chefVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(chefVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(chefVent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new chefVent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton VerId;
    private javax.swing.JButton agregarPlatillo;
    private javax.swing.JButton buscarPorPrecio;
    private javax.swing.JButton eliminarPlatillo;
    private javax.swing.JButton empezar;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton precioAlto;
    private javax.swing.JButton precioBajo;
    private javax.swing.JButton precioBajo1;
    private javax.swing.JButton regresar;
    private javax.swing.JButton verMenu;
    // End of variables declaration//GEN-END:variables
}
