/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyectoestructuras;

import javax.swing.JOptionPane;

/**
 *
 * @author 50662
 */
public class modoMesero extends javax.swing.JFrame {
    public NodoLista cabeza;// hace referencia a la cabeza de la lista
    public NodoLista ultimo;//hace referencia al final de la lista
   int tamaño=0;//lleva el tamaño de la lista
   int contPoder=0;//lleva el contador del poder 
 
    public modoMesero() {
        initComponents();
        this.cabeza=null;
    }

    
    
    public void agregar(Orden orden){
        //Agregamos una orden a la lista
        if (cabeza==null) {
            //si la cabeza es nula entonces insertamos el nodo nuevo a la cabeza de la lista
            
            cabeza=new NodoLista(orden);
            ultimo=cabeza;
            //el ultimo nodo de la lista llega a ser la cabeza
        }else{
            //si la cabeza no esta vacia
            
           ultimo.siguiente=new NodoLista(orden);
           //el ultimo siguiente llega a ser el nuevo nodo 
           
           ultimo=ultimo.siguiente;
           //el nuevo nodo ingresado llega a ser el ultimo 
        }
        tamaño++;
        //aumenta el tamaño de la lista
    }
    
    public void Buscar(){
        //permite buscar un elemento de la lista 
        
        NodoLista aux = cabeza;
        //se crea un nodo para recorrer la lista
        
        int  peticion=Integer.parseInt(JOptionPane.showInputDialog(null,"Digita el numero de orden, por favor..."));
        //se pide el numero de orden a buscar
       int contador=0;
       //se crea un contador para  realizar la  busqueda
       
       String mensaje1="";
       //se crea una variable mensaje que mostrara el mensaje final
       int indicador=0;
       //se crea un indicador para la funcionalidad del metodo
       
        while(true==true){
            contador++;
            
            if (peticion==contador) {
                 mensaje1=("\n"+contador+" "+"||\t"+"Comida= "+ aux.dato.comida+"\n"+"Bebida= "+aux.dato.bebida+"\n"+"Postre= "+aux.dato.postre+ "\t"+"\n");
                 indicador=1;
                break;
                //cuando se encuentra el nodo que se busca el indicador tiene un valor de 1 y sale del ciclo
                
                
            }if(peticion>tamaño||peticion==0){
                break;
                //si la peticion excede el numero de ordenes sale del ciclo
            }
            
            aux = aux.getSiguiente();
            //recorre toda la lista
        }
        if (indicador==1) {
            
            JOptionPane.showMessageDialog(null, mensaje1);
                    //Se mustra la busqueda realizada
        }else{
            
            JOptionPane.showMessageDialog(null, "Lo sentimos, no encontramos ese numero de orden en tu lista...");
            //Se mustra un mensaje de que no se encontro la orden
            
        }
       
    }
    
    
    
  public void Eliminar(){
      //metodo que permite eliminar un nodo
      
      if (cabeza!=null) {
          JOptionPane.showMessageDialog(null, "Has atendido llevado a su mesa la orden "+"\n"+"Comida: "+cabeza.dato.comida+"\n"+"Bebida: "+cabeza.dato.bebida+"\n"+"Postre: "+cabeza.dato.postre);
          contPoder++;
          cabeza=cabeza.siguiente;
          tamaño--;
            if(contPoder==4){
                contPoder=1;
            }
            if (contPoder==3 && cabeza!=null) {
                usarPoder.setEnabled(true);
               
            } else{
                
               
                usarPoder.setEnabled(false); 
                
            }
      }else{
          JOptionPane.showMessageDialog(null, "Lo sentimos, no hay ordenes pendientes...");
      }
      //se mustra el nodo a eliminar y se hacen todos los calculos para que vaya sumando para poder usarse el poder
  }
  
  
  
  
  public void Poder(){
    //EL PODER PODRA USARSE CADA VEZ QUE SE LLEVEN 3 ORDENES SEGUIDAS Y ELIMINARA 3 ORDENES SEGUIDAS
    if (cabeza==null) {
        //SI YA NO HAY ORDENES  MANDARA EL SIGUIENTE MENSAJE Y EN CASO DE QUE EL BOTON ESTE ACTIVADO
        JOptionPane.showMessageDialog(null, "Has acabado con todas las ordenes, felicidades!!!");
    }else{
         //SE ELIMINAN LOS TRES TRASTES DE LA PILA CON EL METODO DE ELIMINAR NODO
    Eliminar();
    Eliminar();
    Eliminar();
   //LLAMA AL METODO ELIMINAR 3 VECES
    }
  
}
    
    public void Mostrar(){

   NodoLista aux = cabeza;
   //se crea un nodo que recorra la lista
   
   int contador=0;
   //un contador para llevar el orden de las ordenes pendientes
   String mensaje1="";
 //nos permite mostrar mensajes al usuario
 
        while(aux!=null){
            contador++;
            mensaje1=mensaje1+("\n"+contador+" "+"||\t"+"Comida= "+ aux.dato.comida+"\n"+"Bebida= "+aux.dato.bebida+"\n"+"Postre= "+aux.dato.postre+ "\t"+"\n");
            aux = aux.getSiguiente();
            //va recorriendo toda la lista y guardando los mensajes en la variable mensaje1 para mostar todo al final
        }
       
        JOptionPane.showMessageDialog(null, mensaje1);
        //se muestra el mensaje cuando sale del ciclo
}    
    
    
    
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Ayuda = new javax.swing.JButton();
        Regresar = new javax.swing.JButton();
        Empezar = new javax.swing.JButton();
        verOrdenes = new javax.swing.JButton();
        buscarOrden = new javax.swing.JButton();
        llevarOrden = new javax.swing.JButton();
        usarPoder = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Mesero");
        setBackground(new java.awt.Color(0, 0, 255));

        jPanel1.setBackground(new java.awt.Color(207, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Ayuda.setBackground(new java.awt.Color(255, 0, 0));
        Ayuda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Ayuda.setForeground(new java.awt.Color(255, 255, 255));
        Ayuda.setText("Ayuda");
        Ayuda.setFocusPainted(false);
        Ayuda.setFocusable(false);
        Ayuda.setRequestFocusEnabled(false);
        Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AyudaActionPerformed(evt);
            }
        });
        jPanel1.add(Ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, -1, 30));

        Regresar.setBackground(new java.awt.Color(255, 0, 0));
        Regresar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setText("Regresar");
        Regresar.setFocusPainted(false);
        Regresar.setFocusable(false);
        Regresar.setRequestFocusEnabled(false);
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        jPanel1.add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 30));

        Empezar.setBackground(new java.awt.Color(255, 0, 0));
        Empezar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Empezar.setForeground(new java.awt.Color(255, 255, 255));
        Empezar.setText("Empezar");
        Empezar.setFocusPainted(false);
        Empezar.setFocusable(false);
        Empezar.setRequestFocusEnabled(false);
        Empezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpezarActionPerformed(evt);
            }
        });
        jPanel1.add(Empezar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, -1, 30));

        verOrdenes.setBackground(new java.awt.Color(246, 170, 0));
        verOrdenes.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        verOrdenes.setForeground(new java.awt.Color(255, 255, 255));
        verOrdenes.setText("Ver Ordenes");
        verOrdenes.setEnabled(false);
        verOrdenes.setFocusPainted(false);
        verOrdenes.setFocusable(false);
        verOrdenes.setRequestFocusEnabled(false);
        verOrdenes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verOrdenesActionPerformed(evt);
            }
        });
        jPanel1.add(verOrdenes, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, -1, -1));

        buscarOrden.setBackground(new java.awt.Color(246, 170, 0));
        buscarOrden.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        buscarOrden.setForeground(new java.awt.Color(255, 255, 255));
        buscarOrden.setText("Bucar Ordenes");
        buscarOrden.setBorderPainted(false);
        buscarOrden.setEnabled(false);
        buscarOrden.setFocusPainted(false);
        buscarOrden.setFocusable(false);
        buscarOrden.setRequestFocusEnabled(false);
        buscarOrden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarOrdenActionPerformed(evt);
            }
        });
        jPanel1.add(buscarOrden, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, -1, -1));

        llevarOrden.setBackground(new java.awt.Color(246, 170, 0));
        llevarOrden.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        llevarOrden.setForeground(new java.awt.Color(255, 255, 255));
        llevarOrden.setText("Llevar orden");
        llevarOrden.setEnabled(false);
        llevarOrden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                llevarOrdenActionPerformed(evt);
            }
        });
        jPanel1.add(llevarOrden, new org.netbeans.lib.awtextra.AbsoluteConstraints(292, 233, -1, -1));

        usarPoder.setBackground(new java.awt.Color(246, 170, 0));
        usarPoder.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        usarPoder.setForeground(new java.awt.Color(255, 255, 255));
        usarPoder.setText("Usar Poder");
        usarPoder.setEnabled(false);
        usarPoder.setFocusPainted(false);
        usarPoder.setFocusable(false);
        usarPoder.setRequestFocusEnabled(false);
        usarPoder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usarPoderActionPerformed(evt);
            }
        });
        jPanel1.add(usarPoder, new org.netbeans.lib.awtextra.AbsoluteConstraints(94, 233, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\50662\\Downloads\\ImagenesProyectoJava\\Mesero1.jpeg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 510, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 301, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        VentanaPrincipal ventanaPrincipal1=new VentanaPrincipal();
        ventanaPrincipal1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegresarActionPerformed

    private void EmpezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpezarActionPerformed
        verOrdenes.setEnabled(true);
        buscarOrden.setEnabled(true);
         llevarOrden.setEnabled(true);
         agregar(new Orden("Hamburgesa Pequeña","Cocacola","Tres Leches"));
         agregar(new Orden("2 Hamburgesas Grandes","2 Pepsi","2 Helado"));
         agregar(new Orden("5 Hamburgesas Medianas","5 Cases", "3 Helados"));
         agregar(new Orden("Hamburgesa Pequeña","Mora","Gelatina"));
         agregar(new Orden("Hamburgesa Grande","Pepsi","Helado"));
         agregar(new Orden("Hamburgesa Pequeña","Cocacola","Tres Leches"));
         agregar(new Orden("Hamburgesa Pequeña","Cocacola","Tres Leches"));
         agregar(new Orden("Hamburgesa Mediana","Mora","Gelatina"));
         Empezar.setEnabled(false);
    }//GEN-LAST:event_EmpezarActionPerformed

    private void verOrdenesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verOrdenesActionPerformed
        Mostrar();
    }//GEN-LAST:event_verOrdenesActionPerformed

    private void buscarOrdenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarOrdenActionPerformed
        Buscar();
    }//GEN-LAST:event_buscarOrdenActionPerformed

    private void llevarOrdenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_llevarOrdenActionPerformed
        Eliminar();
    }//GEN-LAST:event_llevarOrdenActionPerformed

    private void usarPoderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usarPoderActionPerformed
         if (contPoder==3) {
            
            Poder();
           contPoder=0;
           usarPoder.setEnabled(false);
           
        }
    }//GEN-LAST:event_usarPoderActionPerformed

    private void AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AyudaActionPerformed
        AyudaMesero ayudaMesero=new AyudaMesero();
        ayudaMesero.setVisible(true);
    }//GEN-LAST:event_AyudaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(modoMesero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(modoMesero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(modoMesero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(modoMesero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new modoMesero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ayuda;
    private javax.swing.JButton Empezar;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton buscarOrden;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton llevarOrden;
    private javax.swing.JButton usarPoder;
    private javax.swing.JButton verOrdenes;
    // End of variables declaration//GEN-END:variables
}
